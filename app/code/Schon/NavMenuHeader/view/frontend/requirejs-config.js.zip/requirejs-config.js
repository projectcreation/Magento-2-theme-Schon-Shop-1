var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/content.html':
                'Schon_NavMenuHeader/view/frontend/web/template/minicart/content.html',
            'Magento_Checkout/js/view/minicart.js':
                'Schon_NavMenuHeader/view/frontend/web/js/view/minicart.js'
        }
    }
};



